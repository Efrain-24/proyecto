/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import conexion.cls_conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelos.ModeloRegistroUsuario;
import modelos.Pelicula;

/**
 *
 * @author cdramirez
 */
public class PeliculaController {
    
    
    private cls_conexion conectar;
    private Pelicula pelicula;
    private Connection con;
     
    public PeliculaController(){
        conectar = new cls_conexion();
        pelicula = new Pelicula();
    }
     
    public int insertar(Pelicula pelicula_nueva,String boletos,String personas, String forma_de_pago, String comprador, String horario, String lugar){
        PreparedStatement ps;
        String sql;
        pelicula.setNombre(pelicula_nueva.getNombre());
        pelicula.setPrecio(pelicula_nueva.getPrecio());
        try{
            con = conectar.getConnection();
            sql = "insert into compras(nombrepelicula, preciopelicula, correousuario, boletos, personas, forma_de_pago, horario, lugar) values(?,?,?,?,?,?, ?,?)";
            ps = con.prepareStatement(sql);
            
            ps.setString(1, pelicula.getNombre());
            ps.setString(2, Integer.toString(pelicula.getPrecio()));
            ps.setString(3, comprador);
            ps.setString(4, boletos);
            ps.setString(5, personas);
            ps.setString(6, forma_de_pago);
            ps.setString(7, horario);
             ps.setString(8, lugar);
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se han insertado los datos");
            
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error de conexión:" + e.getMessage());
            return 0;
        }
        return 1;
    }
    
}
