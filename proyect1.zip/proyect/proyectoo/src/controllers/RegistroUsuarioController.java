/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import conexion.cls_conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelos.ModeloRegistroUsuario;


public class RegistroUsuarioController {
    
    private cls_conexion conectar;
    private ModeloRegistroUsuario modelo;
    private Connection con;
     
    public RegistroUsuarioController(){
        conectar = new cls_conexion();
        modelo = new ModeloRegistroUsuario();
    }
     
    public void insertar(String correo_electronico, String nombre, String apellido, String password){
        PreparedStatement ps;
        String sql;
        modelo.setCorreo_electronico(correo_electronico);
        modelo.setNombre(nombre);
        modelo.setApellido(apellido);
        modelo.setPassword(password);
        try{
            con = conectar.getConnection();
            sql = "insert into usuario(correo_electronico, nombre, apellido, password) values(?,?,?,?)";
            ps = con.prepareStatement(sql);
            
            ps.setString(1, modelo.getCorreo_electronico());
            ps.setString(2, modelo.getNombre());
            ps.setString(3, modelo.getApellido());
            ps.setString(4, modelo.getPassword());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se han insertado los datos");
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error de conexión:" + e.getMessage());
        }
    }
    
}
