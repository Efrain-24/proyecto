/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;


import conexion.cls_conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelos.ModeloRegistroUsuario;
import java.sql.ResultSet;

/**
 *
 * @author cdramirez
 */
public class IniciarUsuarioController {
    
    
    private cls_conexion conectar;
    private ModeloRegistroUsuario modelo;
    private Connection con;
     
    public IniciarUsuarioController(){
        conectar = new cls_conexion();
        modelo = new ModeloRegistroUsuario();
    }
     
    public int comprobar(String correo_electronico, String password){
        PreparedStatement ps;
        String sql;
        modelo.setCorreo_electronico(correo_electronico);
        modelo.setPassword(password);
        try{
            con = conectar.getConnection();
            sql = "select nombre from usuario where correo_electronico=? AND password=?";
            ps = con.prepareStatement(sql);
            
            ps.setString(1, modelo.getCorreo_electronico());
            ps.setString(2, modelo.getPassword());
            ResultSet nombre = ps.executeQuery();
            
            if(!nombre.next()) {return 0;}
            
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error de conexión:" + e.getMessage());
            return 0;
        }
        
        return 1;
        
    }
    
}
